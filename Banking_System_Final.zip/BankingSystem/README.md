# Banking System

A Java desktop banking application for managing customers, accounts, deposits, withdrawals, internal transfers and transaction history. The application provides separate Manager, Teller and Customer workspaces and stores its data in a local SQLite database.

## Technology

- Java 21
- JavaFX 21.0.13 for the desktop interface
- JDBC and SQLite for persistence
- Maven for dependency management and builds
- JUnit Jupiter for automated tests

## Run locally in IntelliJ IDEA (Windows)

1. Open the `BankingSystem` folder (the folder containing `pom.xml`) in IntelliJ IDEA.
2. Set the Project SDK to JDK 21 and the language level to 21.
3. Allow IntelliJ to import the Maven project and download its dependencies.
4. Open `src/main/java/com/bankingsystem/app/BankingApplication.java`.
5. Run `BankingApplication.main()` using IntelliJ's Run button. The entry point starts the JavaFX window lifecycle through `BankingWindow`.

You do not need Tomcat or a separate database server. You can also start the application with the Maven JavaFX goal:

```bash
mvn clean javafx:run
```

Run the automated tests with:

```bash
mvn clean test
```

## Initial access

The first run creates a Manager account, a demonstration Teller account and ten demonstration Customer accounts when the database is empty. The login screen does not display usernames or passwords. The initial Manager and Teller access details are supplied separately in `Manager_Account_Credentials.docx`. The Manager must change the temporary password at first sign-in.

The Manager workspace includes a Teller Accounts screen. A Manager can create teller logins, view teller accounts, deactivate or reactivate access and reset teller passwords. New and reset teller passwords must be changed at the next sign-in. See [`docs/TELLER_MANAGEMENT.md`](docs/TELLER_MANAGEMENT.md) for the steps.

## Main features

- Separate Manager, Teller and Customer access roles.
- Manager-only teller account administration.
- Customer registration and account creation for Savings, Investment and Cheque accounts.
- Three bank branches with unique codes: Francistown (`FRT`), Palapye (`PAL`) and Gaborone (`GAB`). Account numbers identify the issuing branch.
- Each account displays its branch and branch code.
- Deposits, withdrawals, opening deposits and transfers are submitted as pending transaction requests.
- An active Teller must approve or reject every transaction request before account balances change.
- Transfers debit the source account and credit the destination account together in one database transaction.
- Rejected requests do not change account balances.
- Transaction history contains completed, approved transactions. Customers can also view the status of their own requests.
- Investment accounts require an opening deposit of at least BWP 500.00.
- Cheque accounts are restricted to employed customers with employer details.
- Savings accounts do not allow withdrawals or outgoing transfers.
- Monthly interest is processed automatically by the system for active Savings and Investment accounts. Savings earns 0.05% per month and Investment earns 5% per month. Cheque accounts do not earn interest.
- Interest processing runs automatically at month end and catches up completed months when the application starts. Unique references prevent duplicate credits for the same account and month.
- Monetary calculations use `BigDecimal`; passwords are stored as salted PBKDF2 hashes.

## Project structure

```text
src/main/java/com/bankingsystem/
  app/          Application entry point and JavaFX window lifecycle
  controller/   Login, customer, teller, manager and password-change controllers
  domain/       Customer, accounts, branches, transactions and domain rules
  persistence/  SQLite setup and data-access classes
  security/     Password hashing and verification
  service/      Authentication, banking, automatic interest and teller-management services
  view/         JavaFX login, password-change and role dashboards
src/main/resources/schema.sql
src/test/java/  Automated unit and workflow tests
scripts/        Local verification and database validation helpers
```

## Database

The application creates `data/banking-system.db` on first launch. Set the `BANKING_DB_PATH` environment variable to select a different location. The database schema is loaded from `src/main/resources/schema.sql`.

The database contains these main tables:

- `customers`
- `user_credentials`
- `branches`
- `accounts`
- `transactions` (approved transactions and automatic interest credits)
- `transaction_requests` (pending, approved and rejected requests)

The `accounts` table stores shared account fields, account type and branch code. In Java, `Account` is an abstract superclass with concrete `SavingsAccount`, `InvestmentAccount` and `ChequeAccount` subclasses.

## Development and verification

Run the standard build and test commands:

```bash
mvn clean test
mvn javafx:run
```

For a local check of the non-JavaFX application layers and SQLite schema, run:

```bash
./scripts/run-local-verification.sh
```

That helper compiles the core Java packages, runs the domain smoke checks and validates the SQLite schema and migration behavior. It does not replace the full Maven test suite or a GUI launch test.

A GitHub Actions workflow is included at `.github/workflows/maven-test.yml`. It runs the Maven test suite on pushes and pull requests to `main`.

## Security and deployment considerations

This is a demonstration application, not a production banking platform. Before any real deployment, the system would need a formal security review, multi-factor authentication, stronger account lockout and audit controls, secure hosting, tested backup and recovery procedures, and bank approval of the interest-calculation policy. Change all initial access passwords before sharing or deploying the application.
